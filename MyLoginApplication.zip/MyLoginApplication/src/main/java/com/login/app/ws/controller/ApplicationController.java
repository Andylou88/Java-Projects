package com.login.app.ws.controller;

import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.login.app.ws.model.User;
import com.login.app.ws.services.UserService;

import net.sf.jasperreports.engine.DefaultJasperReportsContext;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.HtmlExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleHtmlExporterOutput;

@Controller
public class ApplicationController {
	
	// Instance of UserService Class in order to access the CRUD methods
	@Autowired
	private UserService userService;
	
	
	// maps /welcome request to welcome method
	// also displays the section that is labeled MODE_HOME onto the welcomepage.jsp
	@RequestMapping("/welcome")
	public String welcome(HttpServletRequest request)
	{
		request.setAttribute("mode", "MODE_HOME");
		return "welcomepage";  
	}
	
	// maps /register request to registration method
	// displays the section that is labeled MODE_REGISTER onto the welcomepage.jsp
	@RequestMapping("/register")
	public String registration(HttpServletRequest request)
	{
		request.setAttribute("mode", "MODE_REGISTER");
		return "welcomepage";
	}
	
	// maps /save-user request to registerUser method
	// create method to save/register new user to database.
	// displays the section that is labeled MODE_REGISTER onto the welcomepage.jsp
	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute User user,BindingResult bindingResult,HttpServletRequest request) 
	{
		if(userService.findByUsernameAndPassword(user.getUsername(), user.getPassword())==null)
		{
			userService.saveMyUser(user);
			request.setAttribute("success", "User account has been created!");
			request.setAttribute("mode", "MODE_REGISTER");
		}
		else
		{
			request.setAttribute("exist", "Username or Password already exist!");
			request.setAttribute("mode", "MODE_REGISTER");
		}
		return "welcomepage";
		
	}
	
	// maps /login request to login method
	// displays the section that is labeled MODE_LOGIN onto the welcomepage.jsp
	@RequestMapping("/login")
	public String login(HttpServletRequest request) 
	{
		request.setAttribute("mode","MODE_LOGIN");
		return "welcomepage";
	}
	
	// maps /allusers request to getAllUsers method
	// displays all users in the database.
	// make use of UserService instance to pull all users
	// and displays the section that is labeled MODE_ALL_USERS onto the welcomepage.jsp
	@GetMapping("/all-users")
	public String getAllUsers(HttpServletRequest request) 
	{
		request.setAttribute("users",userService.getAllUsers());
		request.setAttribute("mode","MODE_ALL_USERS");
		return "welcomepage";
	}
	
	// maps /delete-user request to deleteUser method
	// finds user associated to id parameter and deletes
	// the entry from the database
	@RequestMapping("/delete-user")
	public String deleteUser(@RequestParam int id,HttpServletRequest request)
	{
		userService.deleteUser(id);
		request.setAttribute("users",userService.getAllUsers());
		request.setAttribute("mode","MODE_ALL_USERS");
		return "welcomepage";
	}
	
	// maps /edit-user request to updateUser method
	// finds user by id and then
	// displays page to edit user information
	@RequestMapping("/edit-user")
	public String editUser(@RequestParam int id, HttpServletRequest request)
	{
		request.setAttribute("user",userService.findMyUser(id));
		request.setAttribute("mode","MODE_EDIT_USER");
		return "welcomepage";
	}
	
	// maps /login-user request to loginUser method
	// checks if users credentials are valid and then logs the user in
	// if credentials are valid
	@RequestMapping("/login-user")
	public String loginUser(@ModelAttribute User user, HttpServletRequest request)
	{
		if(userService.findByUsernameAndPassword(user.getUsername(), user.getPassword())!=null)
		{
			request.setAttribute("member",userService.findByUsername(user.getUsername()));
			request.setAttribute("mode","WELCOME_USER");
			return "homepage";
		}
		else
		{
			request.setAttribute("error", "Invalid Username or Password");
			request.setAttribute("mode","MODE_LOGIN");
			return "welcomepage";
		}
		
		
	}
	
	// maps /update-user request to updateUser method
	// updates a users information in account
	// and displays the section that is labeled MODE_ALL_USERS onto the welcomepage.jsp
	@PostMapping("/update-user")
	public String updateUser(@ModelAttribute User user,BindingResult bindingResult,HttpServletRequest request) 
	{
		userService.saveMyUser(user);
		request.setAttribute("users",userService.getAllUsers());
		request.setAttribute("mode", "MODE_ALL_USERS");
		return "welcomepage";
	}
	
	// maps /report request to reportAllUsers method
	// pulls data for all users from loginaccounts table
	// then generates a report with users data
	@RequestMapping("/report-all-users")
	public void reportAllUsers(HttpServletResponse response) throws Exception
	{
		response.setContentType("text/html");
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(userService.getAllUsers());
		InputStream inputStream = this.getClass().getResourceAsStream("/reports/report.jrxml");
		JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, dataSource);
		HtmlExporter exporter = new HtmlExporter(DefaultJasperReportsContext.getInstance());
		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		exporter.setExporterOutput(new SimpleHtmlExporterOutput(response.getWriter()));
		exporter.exportReport();
		
	}

}
