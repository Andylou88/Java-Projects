package com.login.app.ws.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.login.app.ws.model.User;

public interface UserRepository extends CrudRepository<User, Integer> // must add the Entity User in the first parameter of Crud Repository and Integer in the second. 
{

	// method to find user by username and password
	public User findByUsernameAndPassword(String username, String password);

	// method to find user by username
	public Optional<User> findByUsername(String username);
}
