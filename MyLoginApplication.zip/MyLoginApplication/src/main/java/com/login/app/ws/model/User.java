package com.login.app.ws.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//add the Entity annotation in order save fields into the database.
@Entity
@Table(name="loginaccounts") // give the name of the table that will be persisted/manipulated.
public class User {

	// declare fields or variables
	@Id
	private int id;
	private String username;
	private String password;
	private String firstname;
	private String lastname;
	private int age;

	// default constructor
	public User() {};
	
	// Constructor with parmeters username,password,firstname,lastname,age
	public User(String username, String password, String firstname, String lastname, int age) 
	{
		super();
		this.username = username;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
	}

	// setters and getters for each variable
	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getUsername() 
	{
		return username;
	}

	public void setUsername(String username) 
	{
		this.username = username;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	public String getFirstname() 
	{
		return firstname;
	}

	public void setFirstname(String firstname) 
	{
		this.firstname = firstname;
	}

	public String getLastname() 
	{
		return lastname;
	}

	public void setLastname(String lastname) 
	{
		this.lastname = lastname;
	}

	public int getAge() 
	{
		return age;
	}

	public void setAge(int age) 
	{
		this.age = age;
	}

	@Override
	public String toString() 
	{
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", age=" + age + "]";
	}
	
	

}
