package com.login.app.ws.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.login.app.ws.model.User;
import com.login.app.ws.repository.UserRepository;

// This class will persist/save data to the database.
//we will write some logic here to persist data into the database. 

@Service
@Transactional
public class UserService {
	
	// instance of user repository in order to access CRUD operations from the CRUD Repository. 
	private final UserRepository userRepository;
		
		//Constructor for UserService with userRepository as a parameter. 
		public UserService(UserRepository userRepository) 
		{
			this.userRepository = userRepository;
		}
		
	// saves user to the table in the database	
	public void saveMyUser(User user) 
	{		
		userRepository.save(user);
	}
	
	// returns a list of all users in the database
	public List<User> getAllUsers()
	{
		List<User> users = new ArrayList<User>();
		
		
		for(User storedUser:userRepository.findAll()) 
		{
			users.add(storedUser);
		}
		
		
		return users;
	}
	
	// deletes user from database
	public void deleteUser(int id)
	{
		userRepository.deleteById(id);
	}
	
	// finds user in the database
	public User findMyUser(int id) 
	{
		return userRepository.findById(id).get();
		 
	}
	
	// uses username and password to find user in the database 
	public User findByUsernameAndPassword(String username, String password) 
	{
		return userRepository.findByUsernameAndPassword(username, password);
		
	}
	
	// finds user by username in the database
	public User findByUsername(String username) 
	{
		return userRepository.findByUsername(username).get();
		 
	}

}
