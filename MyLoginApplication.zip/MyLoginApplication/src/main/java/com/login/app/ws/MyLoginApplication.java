package com.login.app.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyLoginApplication.class, args);
	}

}

