package com.login.app.ws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.login.app.ws.model.User;
import com.login.app.ws.services.UserService;

@RestController
public class RestContoller {
	
	//create an instance of UserService in order to save user details
	@Autowired
	private UserService userService;
	
	// maps / to print out String below.
	@GetMapping("/")
	public String hello()
	{
		return "This is the Home page.";
	}
	
	
	
	// maps /save-user request to saveUser method
	// this method pulls in the user details and saves user into the database. 
	@GetMapping("/saveuser")
	public String saveUser(@RequestParam String username,@RequestParam String firstname,@RequestParam String lastname,@RequestParam int age,@RequestParam String password) 
	{
		User user = new User(username,password,firstname,lastname,age);
		userService.saveMyUser(user);
		return "User Saved";
	}
}
